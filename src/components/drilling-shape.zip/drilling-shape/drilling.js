import React from "react";
import PropTypes from 'prop-types';

const DrillingShape = (props) => {
    let sumHeight = 460; // margin for show first element
    const resultArray = []
    props.colHeights.map((percent, index) => {
        sumHeight += (percent * 25.8); //each percent of columns = 25.7px
        const resultObj = (
            <g key={index} filter={`url(#filter100${index}_ii_342_898)`}>
                <path d={`M449.6 430.877H330.243V${sumHeight}C375.638 ${sumHeight} 428.729 ${sumHeight} 449.6 ${sumHeight}V430.877Z`} fill="url(#paint1_linear_342_898)" />
            </g>
        )
        resultArray.push(resultObj);
    })
    return (
        <svg width="792" height="3244" viewBox="0 0 792 3244" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g filter="url(#filter1_ii_342_898)">
                <rect x="548.232" y="452.723" width="28.5886" height="1968.33" rx="7" fill="#D2C8C8" />
            </g>
            <rect x="549.232" y="453.723" width="26.5886" height="1966.33" rx="6" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter2_ii_342_898)">
                <rect x="608.981" y="452.723" width="28.5886" height="993.579" rx="7" fill="#D2C8C8" />
            </g>
            <rect x="609.981" y="453.723" width="26.5886" height="991.579" rx="6" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter3_ii_342_898)">
                <rect x="669.733" y="452.723" width="28.5886" height="744.996" rx="7" fill="#D2C8C8" />
            </g>
            <rect x="670.733" y="453.723" width="26.5886" height="742.996" rx="6" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter4_ii_342_898)">
                <rect x="741.919" y="452.723" width="28.5886" height="127.305" rx="7" fill="#D2C8C8" />
            </g>
            <rect x="742.919" y="453.723" width="26.5886" height="125.305" rx="6" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter5_ii_342_898)">
                <rect width="28.5886" height="1968.33" rx="7" transform="matrix(-1 0 0 1 255.199 452.723)" fill="#D2C8C8" />
            </g>
            <rect x="-1" y="1" width="26.5886" height="1966.33" rx="6" transform="matrix(-1 0 0 1 253.199 452.723)" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter6_ii_342_898)">
                <rect width="28.5886" height="993.579" rx="7" transform="matrix(-1 0 0 1 194.448 452.723)" fill="#D2C8C8" />
            </g>
            <rect x="-1" y="1" width="26.5886" height="991.579" rx="6" transform="matrix(-1 0 0 1 192.448 452.723)" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter7_ii_342_898)">
                <rect width="28.5886" height="753.282" rx="7" transform="matrix(-1 0 0 1 133.697 452.723)" fill="#D2C8C8" />
            </g>
            <rect x="-1" y="1" width="26.5886" height="751.282" rx="6" transform="matrix(-1 0 0 1 131.697 452.723)" stroke="#262626" stroke-width="2" />
            <g filter="url(#filter8_ii_342_898)">
                <rect width="28.5886" height="127.305" rx="7" transform="matrix(-1 0 0 1 58.6523 452.723)" fill="#D2C8C8" />
            </g>
            <rect x="-1" y="1" width="26.5886" height="125.305" rx="6" transform="matrix(-1 0 0 1 56.6523 452.723)" stroke="#262626" stroke-width="2" />
            {/*  */}
            {resultArray.reverse().map(item => item)}
            
            <g filter="url(#filter10_ii_342_898)">
                <path d="M275.925 352.535L507.492 352.535L507.492 30.7997C433.325 -14.6235 322.898 -5.66843 275.925 30.7997V352.535Z" fill="url(#paint2_linear_342_898)" />
            </g>
            <g filter="url(#filter11_ii_342_898)">
                <path d="M58.6523 312.661C213.031 285.493 576.105 285.493 733.342 312.661V382.618C516.069 399.078 193.019 389.476 58.6523 382.618V312.661Z" fill="url(#paint3_linear_342_898)" />
            </g>
            <g filter="url(#filter12_ii_342_898)">
                <path d="M0.0458984 369.803C182.586 350.811 604.04 361.89 791.949 369.803V450.523C536.93 469.515 157.755 458.436 0.0458984 450.523V369.803Z" fill="url(#paint4_linear_342_898)" />
            </g>
            <g filter="url(#filter13_ii_342_898)">
                <path d="M283.072 3042.73C333.156 3035.69 448.789 3039.8 500.345 3042.73V3072.62C430.376 3079.66 326.343 3075.55 283.072 3072.62V3042.73Z" fill="url(#paint5_linear_342_898)" />
            </g>
            <g filter="url(#filter14_ii_342_898)">
                <path d="M283.072 3156.36C339.535 3165.28 441.024 3167.54 500.345 3156.36V3186.25C429.589 3198.54 338.105 3196.28 283.072 3186.25V3156.36Z" fill="url(#paint6_linear_342_898)" />
            </g>
            <g filter="url(#filter15_i_342_898)">
                <path d="M500.345 3109.65H283.072V3161.43C344.476 3172.18 448.389 3169.17 500.345 3161.43V3109.65Z" fill="#D69031" />
            </g>
            <path d="M500.345 3095.34H283.072V3130.04C346.05 3140.27 446.027 3139.76 500.345 3130.04V3095.34Z" fill="#3D363D" />
            <g filter="url(#filter16_i_342_898)">
                <path d="M500.345 3071.99H283.072V3101.97C345.263 3107.75 442.878 3108.62 500.345 3101.97V3071.99Z" fill="#E69628" />
            </g>
            <rect x="501.346" y="2311.31" width="26.5886" height="931.316" rx="13.2943" fill="#D2C8C8" stroke="#262626" stroke-width="2" />
            <rect x="272.637" y="2311.31" width="26.5886" height="931.316" rx="13.2943" fill="#D2C8C8" stroke="#262626" stroke-width="2" />
            <defs>
                <filter id="filter0_ii_342_898" x="333" y="2193" width="117" height="278" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1_ii_342_898" x="544.232" y="448.723" width="36.5889" height="1976.33" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter2_ii_342_898" x="604.981" y="448.723" width="36.5889" height="1001.58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter3_ii_342_898" x="665.733" y="448.723" width="36.5889" height="752.996" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter4_ii_342_898" x="737.919" y="448.723" width="36.5889" height="135.305" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter5_ii_342_898" x="222.61" y="448.723" width="36.5889" height="1976.33" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter6_ii_342_898" x="161.859" y="448.723" width="36.5889" height="1001.58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter7_ii_342_898" x="101.108" y="448.723" width="36.5889" height="761.281" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter8_ii_342_898" x="26.0635" y="448.723" width="36.5889" height="135.305" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-4" dy="-4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="4" dy="4" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                {/* <filter id="filter9_ii_342_898" x="320.243" y="420.877" width="139.357" height="1812.81" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter> */}
                {/*  */}
                <filter id="filter1000_ii_342_898" x="320.243" y="420.877" width="145.357" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1001_ii_342_898" x="340.243" y="420.877" width="100.357" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1002_ii_342_898" x="350.243" y="420.877" width="82.357" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1003_ii_342_898" x="358.243" y="420.877" width="68" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1004_ii_342_898" x="365" y="420.877" width="54" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1005_ii_342_898" x="370.5" y="420.877" width="44" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1006_ii_342_898" x="374.5" y="420.877" width="35" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1007_ii_342_898" x="378.3" y="420.877" width="28" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1008_ii_342_898" x="382" y="420.877" width="20" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter1009_ii_342_898" x="385" y="420.877" width="14" height="2620" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                {/*  */}
                <filter id="filter10_ii_342_898" x="270.925" y="-5" width="241.567" height="362.535" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-5" dy="-5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="5" dy="5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter11_ii_342_898" x="53.6523" y="287.285" width="684.69" height="109.422" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-5" dy="-5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="5" dy="5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter12_ii_342_898" x="-4.9541" y="354.316" width="801.903" height="111.693" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-5" dy="-5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="5" dy="5" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter13_ii_342_898" x="273.072" y="3028.84" width="237.273" height="57.6641" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter14_ii_342_898" x="273.072" y="3146.36" width="237.273" height="58.2852" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="effect1_innerShadow_342_898" result="effect2_innerShadow_342_898" />
                </filter>
                <filter id="filter15_i_342_898" x="273.072" y="3099.65" width="227.273" height="68.7559" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="-10" dy="-10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.221667 0 0 0 0 0.215571 0 0 0 0 0.215571 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                </filter>
                <filter id="filter16_i_342_898" x="283.072" y="3071.99" width="227.273" height="44.6504" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                    <feOffset dx="10" dy="10" />
                    <feGaussianBlur stdDeviation="10" />
                    <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.445833 0 0 0 0 0.442118 0 0 0 0 0.442118 0 0 0 0.5 0" />
                    <feBlend mode="normal" in2="shape" result="effect1_innerShadow_342_898" />
                </filter>
                <linearGradient id="paint0_linear_342_898" x1="343" y1="2292" x2="440" y2="2292" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#8C9BDC" />
                    <stop offset="0.520833" stop-color="#C8DCFA" />
                    <stop offset="1" stop-color="#8C9BDC" />
                </linearGradient>
                <linearGradient id="paint1_linear_342_898" x1="449.6" y1="1053.09" x2="330.243" y2="1053.09" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#8C9BDC" />
                    <stop offset="0.552083" stop-color="#C8DCFA" />
                    <stop offset="1" stop-color="#96A2DB" />
                </linearGradient>
                <linearGradient id="paint2_linear_342_898" x1="536.795" y1="131.824" x2="275.912" y2="126.398" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#645A5A" />
                    <stop offset="0.536458" stop-color="#887A7A" />
                    <stop offset="1" stop-color="#3C3737" />
                </linearGradient>
                <linearGradient id="paint3_linear_342_898" x1="182.298" y1="341.989" x2="694.033" y2="341.989" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#3C3737" />
                    <stop offset="0.432292" stop-color="#887A7A" />
                    <stop offset="1" stop-color="#3C3737" />
                </linearGradient>
                <linearGradient id="paint4_linear_342_898" x1="173.721" y1="409.786" x2="636.856" y2="409.786" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#3C3737" />
                    <stop offset="0.450617" stop-color="#887A7A" />
                    <stop offset="1" stop-color="#3C3737" />
                </linearGradient>
                <linearGradient id="paint5_linear_342_898" x1="310.946" y1="3057.68" x2="471.042" y2="3057.68" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#99A6DD" />
                    <stop offset="0.517857" stop-color="#BFD2F5" />
                    <stop offset="1" stop-color="#9BABE3" />
                </linearGradient>
                <linearGradient id="paint6_linear_342_898" x1="316.664" y1="3175.19" x2="473.901" y2="3175.19" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#98A9E2" />
                    <stop offset="0.515625" stop-color="#F2EFF6" />
                    <stop offset="1" stop-color="#98A9E2" />
                </linearGradient>
            </defs>
        </svg>
    )
}

export default DrillingShape;

DrillingShape.propTypes = {
    colHeights : PropTypes.arrayOf(PropTypes.number)
};